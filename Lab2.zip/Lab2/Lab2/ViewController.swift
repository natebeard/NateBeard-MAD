//
//  ViewController.swift
//  Lab2
//
//  Created by Nathan Beard on 9/8/16.
//  Copyright © 2016 natebeard_. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var zeppelinImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var albumImage: UISegmentedControl!
    @IBOutlet weak var fontSize: UILabel!
    @IBOutlet weak var textStyle: UISwitch!
    
    
    
    
    func chooseAlbum() {
        if albumImage.selectedSegmentIndex==0 {
            titleLabel.text = "Led Zeppelin IV"
            zeppelinImage.image=UIImage(named: "ledZeppelinIV")
        }
        else if albumImage.selectedSegmentIndex==1 {
            titleLabel.text = "House of the Holy"
            zeppelinImage.image=UIImage(named: "ledHouseoftheHoly")
        }
        else if albumImage.selectedSegmentIndex==2 {
            titleLabel.text = "Physical Graffiti"
            zeppelinImage.image=UIImage(named: "ledPhysicalGraffiti")
        }
    }
    
    
    
    func updateStyle() {
        if textStyle.on {
            titleLabel.text=titleLabel.text?.uppercaseString
            titleLabel.font=UIFont.boldSystemFontOfSize(20)
            titleLabel.textColor=UIColor.redColor()
            
        } else {
            titleLabel.text=titleLabel.text?.lowercaseString
            titleLabel.font=UIFont.italicSystemFontOfSize(20)
            titleLabel.textColor=UIColor.blueColor()
            
        }
    }
    
   
    
    
    @IBAction func changeTextStyle(sender: UISwitch) {
        updateStyle()
    }
    
    
    @IBAction func changeItAll(sender: UISegmentedControl) {
        updateStyle()
        chooseAlbum()
    }
    
    // update image + caps
    // @IBAction func changeInfo(sender: UISegmentedControl) {
    //    updateImage()
    //    updateCaps()
    // }
    
    
    
    @IBAction func changeFontSize(sender: UISlider) {
        let fontSizeChange=sender.value
        fontSize.text=String(format: "%.0f",fontSizeChange)
        let fontSizeChangeCGFloat=CGFloat(fontSizeChange)
        titleLabel.font=UIFont.systemFontOfSize(fontSizeChangeCGFloat)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

