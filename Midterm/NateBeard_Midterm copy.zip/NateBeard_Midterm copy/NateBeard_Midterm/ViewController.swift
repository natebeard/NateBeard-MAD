//
//  ViewController.swift
//  NateBeard_Midterm
//
//  Created by Nathan Beard on 10/13/16.
//  Copyright © 2016 natebeard_. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    
    @IBOutlet weak var workoutTime: UITextField!
    @IBOutlet weak var milesLabel: UILabel!
    @IBOutlet weak var caloriesLabel: UILabel!
    @IBOutlet weak var activitySegment: UISegmentedControl!
    @IBOutlet weak var imageActivity: UIImageView!
    
    //var minutes = 10
    var miles = 10
    var calories = 600
    var milesTwo = 1
    //var hours = minutes/
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
 
    
   
    @IBAction func chooseActivitySegment(sender: UISegmentedControl) {
        if activitySegment.selectedSegmentIndex == 0 {
            imageActivity.image = UIImage(named:"run")
        } else if activitySegment.selectedSegmentIndex==1 {
            imageActivity.image = UIImage(named:"bike")
        } else if activitySegment.selectedSegmentIndex==2 {
            imageActivity.image = UIImage(named:"swim")
        }
        
        
    }
    
    @IBAction func calculate(sender: UIButton) {
        let runTime = Int(workoutTime.text!)
        let averageRunTime = runTime!/miles
        let hours = runTime!/60
        let caloriesBurned = calories/hours
        
        
        //let bikeSpeed = 15/hours
        //let swimSpeed = 2/hours
        
        if workoutTime.text!.isEmpty {
            milesLabel.text="0"
            
        } else {
            milesLabel.text = "\(averageRunTime) miles"
        }
        
        if workoutTime.text!.isEmpty {
            caloriesLabel.text="0"

        } else {
            caloriesLabel.text = "\(caloriesBurned) calories"
        }
        
        
        
        if runTime < 30 {
            let alert=UIAlertController(title:"Warning", message: "Must workout more than 30 minutes", preferredStyle: UIAlertControllerStyle.Alert)
            let cancelAction=UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: nil)
            alert.addAction(cancelAction)
            let okAction=UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: {
                action in
                self.workoutTime.text="30"
            })
            
            alert.addAction(okAction)
            presentViewController(alert, animated: true, completion: nil)
            
        }

    }
    
    @IBAction func onTapGestureRecognized(sender: AnyObject) {
        workoutTime.resignFirstResponder()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

