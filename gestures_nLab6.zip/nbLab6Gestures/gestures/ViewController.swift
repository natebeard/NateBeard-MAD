//
//  ViewController.swift
//  gestures
//
//  Created by Nathan Beard on 10/6/16.
//  Copyright © 2016 natebeard_. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    
    
    var audioPlayer : AVAudioPlayer?
    
    // NSBundle lets you access this current app's files on this device
    // pathForResource lets you take any file name from app
    @IBAction func handleLongPress(sender: UILongPressGestureRecognizer) {
        let audioFilePath = NSBundle.mainBundle().pathForResource("ChewbaccaSound", ofType: "mp3")
        print(audioFilePath)
        let fileURL = NSURL(fileURLWithPath: audioFilePath!)
        audioPlayer = try? AVAudioPlayer(contentsOfURL: fileURL)
        if audioPlayer != nil {
            audioPlayer!.play()
        }
    }
    
    
    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWithGestureRecognizer otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true // allow multiple gestures to be recognized
    }
    
    
    // transform handles scale and center
    @IBAction func handlePinch(sender: UIPinchGestureRecognizer) {
        sender.view!.transform = CGAffineTransformScale(sender.view!.transform, sender.scale, sender.scale)
        sender.scale=1 // resets scale
    }
    
    
    @IBAction func handleRotate(sender: UIRotationGestureRecognizer) {
        sender.view!.transform = CGAffineTransformRotate(sender.view!.transform, sender.rotation)
        sender.rotation=0 // reset rotation
    }
    
    
    // pan is related to the image center, not the view... we're moving the image by pressing and holding
    // handlePan = name
    // sender is a parameter that has a value and acts as a local variable that we use in the method
    // get translationInView from UIPanGestureRecognizer class
    // view has center property that has x and y, so set new center by adding where it moved to...
    @IBAction func handlePan(sender: UIPanGestureRecognizer) {
        let translation = sender.translationInView(view) //returns new location
        sender.view!.center = CGPoint(x: sender.view!.center.x + translation.x, y: sender.view!.center.y + translation.y)
        sender.setTranslation(CGPointZero, inView: view) // set translation back to 0
        
        // can manipulate speed so that when you drag the image has momentum and will look like throwing it...
    }
    
    
    
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

