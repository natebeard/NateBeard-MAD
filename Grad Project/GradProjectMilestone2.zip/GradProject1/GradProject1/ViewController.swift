//
//  ViewController.swift
//  GradProject1
//
//  Created by Nathan Beard on 11/14/16.
//  Copyright © 2016 natebeard_. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBOutlet weak var message: UILabel!
    
    @IBAction func postToServerButton(sender: UIButton) {
        postRequestData()
        message.text = "\(message)"
    }
    
    
    
    func postRequestData(){
        print("post request data")
        let myUrl = NSURL(string: "http://creative.colorado.edu/~beardn/example.php")
        let request = NSMutableURLRequest(URL: myUrl!)
        request.HTTPMethod = "POST"
        
        let postString = "message=HEY"
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        print("error1")
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil{
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("reponse data = \(responseString)")
            
            //var err: NSError?
            do {
            var json = try NSJSONSerialization.JSONObjectWithData(data!, options: .MutableContainers) as? NSDictionary
            // receives data from arbitrary key/value
            
            
            if let parseJSON = json {
                var messageValue = parseJSON["message"] as? String
                print("messageValue: \(messageValue)")
            }
            }
            catch{
                print("error")
            }
        }
        task.resume()
        
        
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

