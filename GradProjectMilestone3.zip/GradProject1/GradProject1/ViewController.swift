//
//  ViewController.swift
//  GradProject1
//
//  Created by Nathan Beard on 11/14/16.
//  Copyright © 2016 natebeard_. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBOutlet weak var message: UILabel!
    
    @IBAction func postToServerButton(sender: UIButton) {
        postRequestData()
        //message.text = "\(message)"
    }
    
    
    
    func postRequestData(){
        print("post request data")
        let myUrl = NSURL(string: "http://creative.colorado.edu/~beardn/example.php")
        let request = NSMutableURLRequest(URL: myUrl!)
        request.HTTPMethod = "POST"
        
        // Key/value pair
        let postString = "message1=Yes&message2=I am OK"
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
        print("error?")
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            if error != nil{
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("reponse data = \(responseString)")
            
            // var err: NSError?
            // from JSON to NSDictionary
            // changed "var" josn to constant
            do {
            let json = try NSJSONSerialization.JSONObjectWithData(data!, options: .MutableContainers) as? NSDictionary
            // receives data from arbitrary key/value
            
            // changed var messageValue to constant
            if let parseJSON = json {
                let messageValue = parseJSON["message1"] as? String
                let messageValueOK = parseJSON["messageOK"] as? String
                self.message.text = "\(messageValue) \(messageValueOK)"
                print("messageValue: \(messageValue) \(messageValueOK)")
                }
            }
            catch{
                print("error")
            }
        }
        task.resume()
        
        
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

